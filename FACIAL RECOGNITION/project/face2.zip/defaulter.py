import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import pandas as pd

# Initialize Firebase app
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceattendancerealtime-4d6a5-default-rtdb.firebaseio.com/"
})

# Read student attendance data from Firebase
ref = db.reference('Students')
students_data = ref.get()

# Convert student attendance data to pandas dataframe
students_df = pd.DataFrame.from_dict(students_data, orient='index')

# Calculate attendance percentage for each student
students_df['attendance_percentage'] = students_df['total_attendance'] / 15 * 100

# Define attendance threshold for defaulters
attendance_threshold = 60

# Identify defaulters based on attendance threshold
defaulters_df = students_df.loc[students_df['attendance_percentage'] < attendance_threshold]

# Convert defaulters data to Excel sheet
defaulters_df.to_excel('defaulters.xlsx')