import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://faceattendancerealtime-4d6a5-default-rtdb.firebaseio.com/"
})

ref = db.reference('Students')

data = {
    "21106026":
        {
            "name": "Sachin Sapkale",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "21106048": 
        {
            "name": "Jayesh Patil",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "211060100": 
        {
            "name": "Pavan Sapkale",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "211060200":  
        {
            "name": "Narendra Modi",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
    "21106015": 
        {
            "name": "Adrian Thereparambil",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"
        },
        "21106027":
        {
            "name": "Mihir Manjrekar",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"  
        },
        "21106056":
        {
            "name": "Sanjita Shukla",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"  
        },
        "21106058":
        {
            "name": "Chirag Sawant",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"  
        },
        "21106030":
        {
            "name": "Shubham Singh",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"  
        },
        "21106024":
        {
            "name": "Shashikant Shukla",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"  
        },
        "21106035":
        {
            "name": "Vinaykumar Yadav",
            "major": "CSE(AIML)",
            "starting_year": 2022,
            "total_attendance": 0,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2022-12-11 00:54:34"  
        }


}

for key, value in data.items():
    ref.child(key).set(value)

