<?php
	$nationality = $_POST['nationality'];
	$focusArea = $_POST['focusArea'];
	$amount = $_POST['amount'];
	$title = $_POST['title'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$contact = $_POST['contact'];
	$pan = $_POST['pan'];
	$dob = $_POST['dob'];
	$add1 = $_POST['add1'];
	$add2 = $_POST['add2'];
	$postal_code = $_POST['postal_code'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$country = $_POST['country'];

	// Database connection
	$conn = new mysqli('localhost','root','','donate_db');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into donate_info(nationality, focusArea,amount,title,name,email,contact,pan,dob,add1,add2,postal_code,city,state,country) values(?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param('ssisssiisssisss',$nationality, $focusArea,$amount,$title,$name,$email,$contact,$pan,$dob,$add1,$add2,$postal_code,$city,$state,$country);
		$execval = $stmt->execute();
		// echo $execval;
		// // echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Pretty Smiles</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon">
   <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />



	<script src="https://www.google.com/recaptcha/api.js"></script>

    
    <style>
        .card {
          box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
          max-width: 300px;
          margin: auto;
          text-align: center;
          font-family: arial;
        }
        
        .title {
          color: grey;
          font-size: 18px;
        }
        
       .card button {
          border: none;
          outline: 0;
          display: inline-block;
          padding: 8px;
          color: white;
          background-color: #000;
          text-align: center;
          cursor: pointer;
          width: 100%;
          font-size: 18px;
        }
        
        .card a {
          text-decoration: none;
          font-size: 22px;
          color: black;
        }
        
        .card button:hover, a:hover {
          opacity: 0.7;
        }
        </style>


</head>

<body>

    <header class="continer-fluid ">
        <div  class="header-top">
            <div class="container">
                <div class="row col-det">
                    <div class="col-lg-6 d-none d-lg-block">
                        <ul class="ulleft">
                            <li>
                                <i class="far fa-envelope"></i>
                                prettysmiles@ngo.com
                                <span>|</span></li>
                            <li>
                                <i class="fas fa-phone-volume"></i>
                                022 987 6663</li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-6 folouws">
                      
                        <ul class="ulright">
                           <li> <small>Folow Us </small>:</li>
                            <li>
                                <i class="fab fa-facebook-square"></i>
                            </li>
                            <li>
                                <i class="fab fa-twitter-square"></i>
                            </li>
                            <li>
                                <i class="fab fa-instagram"></i>
                            </li>
                            <li>
                                <i class="fab fa-linkedin"></i>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-3 d-none d-md-block col-md-6 btn-bhed">
                        <button class="btn btn-sm btn-success">Join Us</button>
                        <button class="btn btn-sm btn-default"><a href="pay/donate.html">Donate</a></button>
                    </div>
                </div>
            </div>
        </div>
        <div id="menu-jk" class="header-bottom">
            <div class="container">
                <div class="row nav-row">
                    <div class="col-lg-3 col-md-12 logo">
                        <a href="index.html">
                            <img src="assets/images/logo.png" alt="">
                            <a data-toggle="collapse" data-target="#menu" href="#menu"><i class="fas d-block d-lg-none  small-menu fa-bars"></i></a>
                        </a>
    
                    </div>
                    <div id="menu" class="col-lg-9 col-md-12 d-none d-lg-block nav-col">
    
                                <ul class="navbad">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="index.html">Home
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="about_us.html">About Us</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="services.html">Services</a>
                                    </li>
    
                                    <li class="nav-item">
                                        <a class="nav-link" href="gallery.html">Gallery</a>
                                    </li>
    
                                    <li class="nav-item">
                                        <a class="nav-link" href="blog.html">Blog</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="contact_us.html">Contact US</a>
                                    </li>
    
    
    
    
                                </ul>
    
    
                    </div>
                </div>
            </div>
        </div> 
    </header>
   <!--  ************************* Page Title Starts Here ************************** -->
        
   <div class="page-nav no-margin row">
    <div class="container">
        <div class="row">
            <h2>Donate</h2>
            <ul>
                <li> <a href="#"><i class="fas fa-home"></i> Home</a></li>
                <li><i class="fas fa-angle-double-right"></i> Donate</li>
                <li><i class="fas fa-angle-double-right"></i> Payment</li>

            </ul>
        </div>
    </div>
</div>

<div style="margin-left:600px; margin-top:50px">
<form action="" method="post">
    <h1> I'm not a Robot</h1>
    
    <!-- <div class="g-recaptcha" data-sitekey="6Ldbdg0TAAAAAI7KAf72Q6uagbWzWecTeBWmrCpJ"></div> -->
    <iframe title="reCAPTCHA" src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6Ldbdg0TAAAAAI7KAf72Q6uagbWzWecTeBWmrCpJ&amp;co=aHR0cHM6Ly9ydW4ucGxua3IuY286NDQz&amp;hl=en-GB&amp;v=6MY32oPwFCn9SUKWt8czDsDw&amp;size=normal&amp;cb=9lt7tfzbdm4" width="304" height="78" role="presentation" name="a-bqumtek2i2oc" frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe>
		<br>
        <br>
        <br>	    
        <button style="margin-left:60px">
            <script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_JiqbzU7dEiv7Ea" async> 
            </script>
            </button>

  </form>
	</div>
      <footer class="footer" style="margin-top: 50px;">
        <div class="container">
            <div class="row">
               
                <div class="col-md-4 col-sm-12">
                    <h2>Useful Links</h2>
                    <ul class="list-unstyled link-list">
                        <li><a ui-sref="about" href="#/about">About us</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="portfolio" href="#/portfolio">Portfolio</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="products" href="#/products">Latest jobs</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="gallery" href="#/gallery">Gallery</a><i class="fa fa-angle-right"></i></li>
                        <li><a ui-sref="contact" href="#/contact">Contact us</a><i class="fa fa-angle-right"></i></li>
                    </ul>
                </div>
                <div class="col-md-4 col-sm-12 map-img">
                    <h2>Contact Us</h2>
                    <address class="md-margin-bottom-40">
                        BlueDart <br>
                        Marthandam (K.K District) <br>
                        Tamil Nadu, IND <br>
                        Phone: +91 9159669599 / 022 487 8870 <br>
                        Email: <a href="mailto:info@anybiz.com" class="">prettysmiles@ngo.com</a><br>
                    </address>

                </div>
            </div>
            
            
            <div class="nav-box row clearfix">
                <div class="inner col-md-9 clearfix">
                    <ul class="footer-nav clearfix">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Gallery</a></li>
                        <li><a href="#">Servies</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>

                  
                </div>
                  <div class="donate-link col-md-3"><a href="donate.html" class="btn btn-primary "><span class="btn-title">Donate Now</span></a></div>
            </div>
            
        </div>
        

        </footer>
    <div class="copy">
            <div class="container">
                <a href="https://www.smarteyeapps.com/">2015 &copy; All Rights Reserved | Designed and Developed by Pretty Smiles</a>
                
                <span>
                <a><i class="fab fa-github"></i></a>
                <a><i class="fab fa-google-plus-g"></i></a>
                <a><i class="fab fa-pinterest-p"></i></a>
                <a><i class="fab fa-twitter"></i></a>
                <a><i class="fab fa-facebook-f"></i></a>
        </span>
            </div>

        </div>
          
    
</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>
<script src="assets/plugins/slider/js/owl.carousel.min.js"></script>
<script src="assets/js/script.js"></script>

</html>